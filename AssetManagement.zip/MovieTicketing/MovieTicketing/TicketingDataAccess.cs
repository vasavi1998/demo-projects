﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";
        public bool AddMovie(Movies obj)
        {
            if (obj == null)
                return false;
            else
            {
                string am = "INSERT INTO MOVIES VALUES ('"+obj.MovieName+"','"+obj.DirectorName+"','"+obj.PlaysPerDay+"','"+obj.TicketPrice+"')";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(am, con);
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public bool AddTheatre(Theatres obj)
        {
            if (obj == null)
                return false;
            else
            {
                string at = "INSERT INTO THEATRES VALUES ('" + obj.TheatreName+ "','" + obj.SeatingCapacity+ "')";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(at, con);
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public bool AddShow(Shows obj)
        {
            if (obj == null)
                return false;
            else
            {
                obj.StartDate = DateTime.Now;
                string addsh = "INSERT INTO SHOWS VALUES ('" + obj.TheatreID+ "','" + obj.MoiveID + "','"+obj.StartDate+"','"+obj.EndDate+"','"+obj.StartTime+"','"+obj.EndTime+"')";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(addsh, con);
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public string AddTicket(Tickets obj)
        {
            if (obj == null)
            {
                return null;
            }
            else
            {
                SqlConnection objConnect = new SqlConnection();

                string moviename = string.Empty;
                decimal ticketprice = 0;
                string v = "SELECT MOVIENAME,TICKETPRICE FROM MOVIES WHERE MOVIEID IN (SELECT MOVIEID FROM SHOWS WHERE SHOWID = '" + obj.ShowID + "')";
                SqlCommand sm = new SqlCommand(v, objConnect);

                SqlDataReader se = sm.ExecuteReader();

                if (se.HasRows)
                {
                    while (se.Read())
                    {
                        moviename = se.GetString(0);
                        ticketprice = (decimal)se.GetSqlMoney(1);
                    }
                }
                se.Close();
                Random r = new Random();
                int t = r.Next(1, 1000);
                string s = obj.CustomerName.Substring(0, 2) + obj.NumberofPersons.ToString() + moviename.Substring(0, 2) + obj.BookingDate.Day + obj.BookingDate.Month + r.Next(1, 1000).ToString();
                s.ToUpper();
                obj.ReferenceCode = s;
                string z = "INSERT INTO TICKETS VALUES('" + obj.ShowID + "','" + obj.ReferenceCode + "','" + obj.CustomerName + "','" + obj.NumberofPersons + "','" + obj.BookingDate + "','" + obj.Amount + "','" + obj.TicketStatus + "')";
                if (objConnect.State == System.Data.ConnectionState.Closed)
                    objConnect.Open();
                SqlCommand SZ = new SqlCommand(z, objConnect);
                int y = SZ.ExecuteNonQuery();
                if (y > 0)
                {
                    return s;
                }
                else
                    return null;

            }

        }
        public int DeleteMovie(int intMovieID)
        {
            string moviename = string.Empty;
            SqlConnection objConnect = new SqlConnection();
            string nv = "SELECT  MOVIENAME FROM MOVIES WHERE MOVIEID ='" + intMovieID + "'";
            SqlCommand sd = new SqlCommand(nv, objConnect);
            SqlDataReader rs = sd.ExecuteReader();
            if (rs.HasRows)
            {
                while (rs.Read())
                    moviename = rs.GetString(0);
            }
            rs.Close();
            if (string.IsNullOrEmpty(moviename))
            {
                return 0;
            }
            else
            {
                int count = 0;
                string a = "DELETE TICKETS WHERE SHOWID=(SELECT SHOWID FROM SHOWS WHERE MOVIEID='" + intMovieID + "')";
                SqlCommand sv = new SqlCommand(a, objConnect);
                int c = sv.ExecuteNonQuery();
                if (c > 0)
                    count++;
                string a1 = "DELETE SHOWS WHERE SHOWID=(SELECT SHOWID FROM SHOWS WHERE MOVIEID='" + intMovieID + "')";
                SqlCommand sv1 = new SqlCommand(a1, objConnect);
                int c1 = sv1.ExecuteNonQuery();
                if (c1 > 0)
                    count++;
                string a2 = "DELETE MOVIES WHERE MOVIEID=(SELECT MOVIEID FROM MOVIES WHERE MOVIEID='" + intMovieID + "')";
                SqlCommand sv2 = new SqlCommand(a2, objConnect);
                int c2 = sv2.ExecuteNonQuery();
                if (c2 > 0)
                    count++;
                return count;

            }
        }
    }
}
