﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeData obj = new EmployeeData();
            obj.AddEmployee(new Employee("John","Smith",2012,12,01,"DEMO",10000));
            obj.ModifyEmployee(new Employee("Will","Smith",2001,3,15,"DEMO",15));
        }
    }
}
