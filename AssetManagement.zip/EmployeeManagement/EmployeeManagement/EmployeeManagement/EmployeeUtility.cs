﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            string UID = string.Empty;
            char c1 = (char)(obj.FirstName[0] + obj.FirstName.Count());
            char c2 = (char)(obj.LastName[0] + obj.LastName.Count());
            UID = c1.ToString() + c2.ToString()+SumDigits(obj.BirthYear)+ SumDigits(obj.BirthMonth)+ SumDigits(obj.BirthDay)+EmployeeCount.ToString();
            obj.UserID = UID;
        }

        public string SumDigits(int value)
        {
            int sum = 0;
            while (value > 0)
            {
                sum += value % 10;
                value = value / 10;
            }
            return sum.ToString();
        }
    }
}
