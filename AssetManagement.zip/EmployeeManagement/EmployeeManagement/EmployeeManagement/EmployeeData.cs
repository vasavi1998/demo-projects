﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        //TODO : Write your code here.
        public List<Employee> EmployeeList { get; set; }

        public EmployeeData()
        {
            EmployeeList = new List<Employee>();
        }
        public string AddEmployee(Employee obj)
        {
            if (obj == null)
                return null;

            EmployeeList.Add(obj);
            return obj.UserID;
        }

        public bool ModifyEmployee(Employee obj)
        {
            bool isModified = false;
            if (obj == null)
                return isModified;
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == obj.UserID)
                    {
                        EmployeeList[i].FirstName = obj.FirstName;
                        EmployeeList[i].LastName = obj.LastName;
                        EmployeeList[i].BirthDay = obj.BirthDay;
                        EmployeeList[i].Experience = obj.Experience;
                        EmployeeList[i].BirthMonth = obj.BirthMonth;
                        EmployeeList[i].BirthYear = obj.BirthYear;
                        EmployeeList[i].Qualification = obj.Qualification;
                        EmployeeList[i].Password = obj.Password;
                        isModified = true;
                    }
                }
            }
            return isModified;
        }

        public Employee SearchEmployee(string strUserID)
        {
            Employee objResult = null;
            if (!string.IsNullOrEmpty(strUserID))
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        objResult = EmployeeList[i];
                    }
                }
            }
            return objResult;
        }

        public bool DeleteEmployee(string strUserID)
        {
            bool IsDeleted = false;
            if (!string.IsNullOrEmpty(strUserID))
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        EmployeeList.RemoveAt(i);
                        IsDeleted = true;
                    }
                }
            }
            return IsDeleted;
        }
    }
}
