﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectData
    {
        const string ConnectionString = "Server=.;Initial Catalog=ProjectManagement;User ID=sa;Password=wipro@123";
        public string AddProject(Project obj)
        {
            if (obj == null)
                return null;
            else
            {
                ProjectUtility pu = new ProjectUtility();
                string id = pu.GenerateProjectID(obj.ProjectName);
                Random r = new Random();
                id += r.Next(100, 1000);
                obj.ProjectID = id;
                int d = (obj.StartDate - obj.EndDate).Days;
                obj.Duration = d;
                string ap = "INSERT INTO PROJECTS VALUES ('" + obj.ProjectID + "','" + obj.ProjectName+ "','"+obj.StartDate+"','"+obj.EndDate+"','"+obj.Duration+"')";
                SqlConnection con = new SqlConnection(ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(ap, con);
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                    return obj.ProjectID;
                else
                    return null;
            }
        }

        public Project GetProjctByID(string strProjectID)
        {
            if (strProjectID == null)
                return null;
            else
            {
                string sn = "SELECT * FROM PROJECTS WHERE PROJECTID = '"+strProjectID+"'";
                SqlConnection conObj = new SqlConnection(ConnectionString);
                conObj.Open();
                SqlCommand search = new SqlCommand(sn, conObj);
                SqlDataReader objReader = search.ExecuteReader();
                if (objReader.HasRows)
                {
                    Project srcObj= new Project();
                    objReader.Read();
                    srcObj.ProjectID = objReader[0].ToString();
                    srcObj.ProjectName = objReader[1].ToString();
                    srcObj.StartDate = (DateTime)objReader[2];
                    srcObj.EndDate = (DateTime)objReader[3];
                    srcObj.Duration = (int)objReader[4];
                    return srcObj;
                    
                }
                else
                    return null;
            }
        }

        public int UpdateProject(Project obj)
        {
            if (obj == null)
                return -1;
            else
            {
                string sn = "UPDATE PROJECTS SET PROJECTNAME = '" + obj.ProjectName + "',STARTDATE = '" + obj.StartDate + "',ENDDATE = '" + obj.EndDate + "',DURATION = '" + obj.Duration + "' WHERE PROJECTID ='" + obj.ProjectID + "'";
                SqlConnection sqc = new SqlConnection(ConnectionString);
                sqc.Open();
                SqlCommand update = new SqlCommand(sn, sqc);
                int i = update.ExecuteNonQuery();
                sqc.Close();
                if (i >= 0)
                    return i;
                else
                    return 0;
            }
        }

        public int DeleteProject(string strProjectID)
        {
            if (strProjectID == null || strProjectID == String.Empty)
                return -1;
            else
            {
                string sn = "DELETE FROM PROJECTS WHERE PROJECTID = '" + strProjectID + "'";
                SqlConnection objCon = new SqlConnection(ConnectionString);
                objCon.Open();
                SqlCommand delete = new SqlCommand(sn, objCon);
                int i = delete.ExecuteNonQuery();
                objCon.Close();
                if (i >= 0)
                    return i;
                else
                    return 0;

            }
        }
    }
}
