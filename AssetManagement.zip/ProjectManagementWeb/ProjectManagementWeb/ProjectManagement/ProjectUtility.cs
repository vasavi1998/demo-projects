﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectUtility
    {
        public string GenerateProjectID(string strProjectName)
        {
            int count = 0;
            string pid = string.Empty;
            string[] s= strProjectName.Split(' ');
            foreach (var item in s)
            {
                count++;
            }
            if (count == 1)
            {
                pid = s[0].Substring(0, 3).ToUpper();
            }
            if (count == 2)
            {
                pid = s[0].Substring(0,1)+s[1].Substring(0, 2);
                pid = pid.ToUpper();
            }
            if (count == 3)
            {
                pid = s[0].Substring(0, 1) + s[1].Substring(0, 1) + s[2].Substring(0, 1);
                pid = pid.ToUpper();
            }
            return pid;
        }
    }
}
