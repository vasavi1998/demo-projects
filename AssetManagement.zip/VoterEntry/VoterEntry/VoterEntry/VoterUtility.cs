﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {
        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            string VID = string.Empty;
            string d = dtDateofBirth.DayOfWeek.ToString();
            VID = strFirstName[0].ToString() + strLastName[0].ToString() + d[0] + strFirstName.Count() + strLastName.Count() + SumDigits(dtDateofBirth.Month) + SumDigits(dtDateofBirth.Day) + SumDigits(dtDateofBirth.Year);
            return VID;
        }
        public string SumDigits(int value)
        {
            int sum = 0;
            while (value > 0)
            {
                sum += value % 10;
                value = value / 10;
            }
            return sum.ToString();
        }
    }
}
