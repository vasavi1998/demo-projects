﻿using System;
using System.Collections.Generic;
namespace VoterEntry
{
    public class VoterManagement
    {
        // TODO: Write your code here
        public List<Voter> VoterList { get; set; }

        public VoterManagement()
        {
            VoterList = new List<Voter>();
            
        }

        public string AddVoter(Voter obj)
        {
            if (obj == null)
                return null;
            else if (string.IsNullOrEmpty(obj.FirstName) || string.IsNullOrEmpty(obj.LastName) || string.IsNullOrEmpty(obj.DateofBirth.ToString()) || string.IsNullOrEmpty(obj.FathersName) || string.IsNullOrEmpty(obj.Gender) || string.IsNullOrEmpty(obj.Address) || string.IsNullOrEmpty(obj.ConstituencyName))
                return null;
            else
            {
                TimeSpan span = DateTime.Now.Subtract(obj.DateofBirth);
                obj.Age = (span.Days / 365);
                if (obj.Age < 18)
                    throw new Exceptions.AgeException("Age shouldn't be less than 18");
                else
                {
                    VoterList.Add(obj);
                    VoterEntry.Utility.VoterUtility ee = new Utility.VoterUtility();
                    obj.VoterID = ee.GenerateVoterID(obj.FirstName, obj.LastName, obj.DateofBirth);
                    return obj.VoterID;
                }
            }
         }

        public bool ModifyVoter(Voter obj)
        {
            bool isModified = false;
            if (obj == null)
                return isModified;
            else
            {
                for (int i = 0; i < VoterList.Count; i++)
                {
                    if (VoterList[i].VoterID == obj.VoterID)
                    {
                        TimeSpan span = DateTime.Now.Subtract(obj.DateofBirth);
                        obj.Age = (span.Days / 365);
                        if (obj.Age < 18)
                            throw new Exceptions.AgeException("Age shouldn't be less than 18");
                        else
                        {
                            VoterList[i].FirstName = obj.FirstName;
                            VoterList[i].LastName = obj.LastName;
                            VoterList[i].DateofBirth = obj.DateofBirth;
                            VoterList[i].Age = obj.Age;
                            VoterList[i].FathersName = obj.FathersName;
                            VoterList[i].Gender = obj.Gender;
                            VoterList[i].Address = obj.Address;
                            VoterList[i].ConstituencyName = obj.ConstituencyName;
                            isModified = true;
                        }
                     }
                 }
            }
            return isModified;
        }
       
        public Voter SearchVoter(string strVoterID)
        {
            Voter objResult = null;
            if (!string.IsNullOrEmpty(strVoterID))
            {
                for (int i = 0; i < VoterList.Count; i++)
                {
                    if (VoterList[i].VoterID == strVoterID)
                    {
                        objResult = VoterList[i];
                    }
                }
            }
            return objResult;
        }

        public bool DeleteVoter(string strVoterID)
        {
            bool IsDeleted = false;
            if (!string.IsNullOrEmpty(strVoterID))
            {
                for (int i = 0; i < VoterList.Count; i++)
                {
                    if (VoterList[i].VoterID == strVoterID)
                    {
                        VoterList.RemoveAt(i);
                        IsDeleted = true;
                    }
                }
            }
            return IsDeleted;
        }

        public List<Voter> GetVoterList()
        {
            return VoterList;
        }
    }
}
