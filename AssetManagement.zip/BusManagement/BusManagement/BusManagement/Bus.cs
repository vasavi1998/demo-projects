﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class Bus : Vehicle
    {
        public string BusID { get; set; }
        public string BusName{ get; set; }
        public int ServiceNumber { get; set; }
        public string ReservationClass { get; set; }
        public double TicketPrice{ get; set; }
        public Bus()
        {

        }
    }
}
