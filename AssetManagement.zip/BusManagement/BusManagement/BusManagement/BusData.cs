﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class BusData
    {
        public List<Bus> BusList { get; set; }

        public BusData()
        {
            BusList = new List<Bus>();
        }

        public string AddBus(Bus objBus)
        {
            if (objBus == null)
                return null;
            else
            {
                Utility.BusUtility bu = new Utility.BusUtility();
                objBus.BusID = bu.GenerateBusID(objBus.Source,objBus.Destination,objBus.ServiceNumber);
                objBus.BusName = bu.GenerateBusName(objBus.Source,objBus.Destination);
                objBus.TicketPrice = bu.FindTicketPrice(objBus.Distance,objBus.ReservationClass);
                BusList.Add(objBus);
                return objBus.BusID;

            }
        }
    }
}
