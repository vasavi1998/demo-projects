﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement.Utility
{
    public class BusUtility
    {
        public string GenerateBusID(string Source, string Destination, int ServiceNumber)
        {
            int count = 0,s=ServiceNumber;
            string BID = string.Empty;
            BID += Source[0].ToString().ToUpper() + Destination[0].ToString().ToUpper()+"-";
            while (s > 0)
            {
                if(s%10!=0)
                {
                    count++;
                    s = s/10;
                }
            }
            switch (count)
            {
                case 1:
                    BID += "00" + ServiceNumber;break;
                case 2:
                    BID += "0" + ServiceNumber;break;
                case 3:
                    BID += ServiceNumber;break;  
            }
            return BID;
        }

        public string GenerateBusName(string Source, string Destination)
        {
            string BName = string.Empty;
            BName = Source[0].ToString().ToUpper() + Source[1].ToString().ToLower() + Source[2].ToString().ToUpper()+"-";
            BName += Destination[0].ToString().ToUpper() + Destination[1].ToString().ToLower() + Destination[2].ToString().ToUpper();
            return BName;
        }

        public double FindTicketPrice(int Distance, string ReservationClass)
        {
            double price=0;
            if (ReservationClass == "AC")
                price = Distance * 3.5;
            else if (ReservationClass == "NAC")
                price = Distance * 2;
            return price;
        }
    }
}
