﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class countMin
    {
        static int res(int input1,int input2, int input3,int input4)
        {
            int l = (input1.ToString().Length) + (input2.ToString().Length) + (input3.ToString().Length) + (input4.ToString().Length);
            int[] num = new int[l];
            int i = 0;
            while (input1 > 0)
            {
                num[i] = input1 % 10;
                input1 /= 10;
                i++;
            }
            while (input2 > 0)
            {
                num[i] = input2 % 10;
                input2 /= 10;
                i++;
            }
            while (input3 > 0)
            {
                num[i] = input3 % 10;
                input3 /= 10;
                i++;
            }
            while (input4 > 0)
            {
                num[i] = input4 % 10;
                input4 /= 10;
                i++;
            }
            Array.Sort(num);
            int[] count = new int[10];
            for (i = 0; i < num.Length; i++)
            {
                count[num[i]]++;
            }
            int mincount = count[0];
            for (i = 0; i < count.Length; i++)
            {
                if (mincount == 0)
                {
                    mincount = count[i];
                }
                else
                {
                    break;
                }
            }
            for (i = 0; i < count.Length; i++)
            {
                if (count[i] != 0 && (mincount > count[i]))
                {
                    mincount = count[i];
                }
            }
            for (i = 0; i < count.Length; i++)
            {
                if (count[i] == mincount)
                    return i;
            }
            return 0;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(res(123,234,21,23));
        }
    }
}
