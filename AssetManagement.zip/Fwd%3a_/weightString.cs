﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    //if input1 = "AbcDe" input2 = 0 => 0+2+3+4+0 = 9
    // if input1 = "AbcDe" input2 = 1 => 1+2+3+4+5 = 15
    class weightString
    {
        static int weight(string input1,int input2)
        {
            input1 = input1.ToUpper();
            string s = input1;
            int res = 0;
            if (input2 == 1)
            {
                for (int i = 0; i < input1.Length; i++)
                {
                    if (s[i] >= 'A' && s[i] <= 'Z')
                        res += (int)(input1[i]) - 64;
                }
            }
            else
            {
                for (int i = 0; i < input1.Length; i++)
                {
                    if ((s[i] >= 'A' && s[i] <= 'Z') && (s[i] != 'A' && s[i] != 'E' && s[i] != 'I' && s[i] != 'O' && s[i] != 'U'))
                        res += (int)(input1[i]) - 64;
                }
            }
            return res;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(weight("deePIka",0));
            Console.ReadKey();
        }
    }
}
