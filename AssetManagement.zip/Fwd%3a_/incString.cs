﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class incString
    {
        static string met(string input1)
        {
            int c = 0;
            char ch;
            string[] ip = input1.Split(' ');
            string[] op = new string[ip.Length];
            string res = "";
            for (int i = 0; i < ip.Length; i++)
            {
                c = ip[i].Length;
                for (int j = 0; j < ip[i].Length; j++)
                {
                    ch = (char)((char)ip[i][j] + c);
                    if (char.IsUpper((char)ip[i][j]) && ch > 'Z')
                        op[i] += "Z";
                    else if (char.IsLower((char)ip[i][j]) && ch > 'z')
                        op[i] += "z";
                    else
                        op[i] += ch;
                }
            }
            for (int i = 0; i < op.Length; i++)
            {
                res += op[i] + " ";
            }
            return res.Trim();
        }
        static void Main(string[] args)
        {
            Console.WriteLine(met("AbcXx"));
            Console.ReadKey();
        }
    }
}
