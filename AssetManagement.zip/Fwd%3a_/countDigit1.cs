﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class countDigit1
    {
        //if inp = 12123 => out = 3
        static void Main(string[] args)
        {
            int input1 = int.Parse(Console.ReadLine());
            int l = input1.ToString().Length;
            int temp = input1, c = 1;
            int[] a = new int[l];
            for (int i = 0; i < l; i++)
            {
                a[i] = temp % 10;
                temp /= 10;
            }
            Array.Sort(a);
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[i] != a[j])
                    {
                        c++;
                        i = j;
                    }
                }
            }
            Console.WriteLine(c);
            Console.ReadKey();
        }
    }
}

