﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class primeRange
    {
        static void Main(string[] args)
        {
            int c = 0, count = 0;
            int input1 = int.Parse(Console.ReadLine());
            int input2 = int.Parse(Console.ReadLine());
            for (int i = input1; i <= input2; i++)
            {
                c = 0;
                for (int j = 2; j <= i / 2; j++)
                {
                    if (i % j == 0)
                    {
                        ++c;
                        break;
                    }
                }
                if (c == 0)
                {
                    ++count;
                }
            }
            Console.WriteLine(count);
            Console.ReadKey();
        }
    }
}
