﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class countDigit2
    {
        
        //if inp = 12123 => out = 1
        static void Main(string[] args)
        {
            
            int input1 = int.Parse(Console.ReadLine());
            int c = 0, flag = 0, temp = input1;
            int l = input1.ToString().Length;
            int[] a = new int[l];
            for (int i = 0; i < l; i++)
            {
                a[i] = temp % 10;
                temp = temp / 10;
            }
            
            Array.Sort(a);
            for (int i = 0; i < l; i++)
            {
                for (int j = 0; j < l; j++)
                {
                    if (i != j)
                    {
                        if (a[i] != a[j])
                        {
                            flag = 1;
                        }
                        else
                        {
                            flag = 0;
                            break;
                        }
                    }
                }
                if (flag == 1)
                {
                    c++;
                }
            }
            if (l == 1)
                c = 1;
            Console.WriteLine(c);
            
            Console.ReadKey();
            
        }
    }
}
