﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class nPrime2
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int c = 0;
            int i = 1;
            while(n>0)
            {
                i = i + 1;
                for (int j = 2; j <= i/2; j ++)
                {
                    if(i%j == 0)
                    {
                        c++;
                        break;
                    }
                }
                if(c == 0)
                {
                    n = n - 1;
                }
                c = 0;
            }
            Console.WriteLine(i);
            Console.ReadKey();
        }
    }
}
