﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class strPalin
    {
        static int palin(string input1)
        {
            input1 = input1.ToLower();
            string res = "";
            char[] s = new char[input1.Length];
            int j = 0;
            for (int i = input1.Length - 1; i >= 0; i--)
            {
                s[i] = input1[j];
                j++;
            }
            for(int i = 0; i < input1.Length; i ++)
            {
                res += s[i];
            }
            if (input1.Equals(res))
            {
                return 2;
            }
            return 1;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(palin("MADam"));
            Console.ReadKey();
        }
    }
}
