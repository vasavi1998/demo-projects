﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class palinPossible
    {
        static int palin(int input1)
        {
            if (input1 <= 9)
            {
                return 2;
            }
            int temp = input1, c = 0;
            int l = input1.ToString().Length;
            int[] a = new int[l];
            for (int i = 0; i < l; i++)
            {
                a[i] = temp % 10;
                temp /= 10;
            }
            Array.Sort(a);
            if (input1 <= 99)
            {
                if (a[0] == a[1])
                {
                    return 2;
                }
            }
            if (input1 <= 999)
            {
                if (a[0] == a[1] || a[0] == a[2] || a[1] == a[2])
                    return 2;
            }
            if (input1 <= 9999)
            {
                if ((a[0] == a[1]) && (a[2] == a[3]))
                    return 2;
            }
            if (input1 > 9999)
            {
                for (int i = 0; i < l; i++)
                {
                    for (int j = i + 1; j < l; j++)
                    {
                        if (a[i] == a[j])
                        {
                            c++;
                            i = i + 1;
                        }
                    }
                }
                if (c == 2)
                {
                    return 2;
                }
            }
            return 1;
        }
        static void Main(string[] args)
        {
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine(palin(i));
        }
    }
}
