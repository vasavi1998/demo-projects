﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class nPrime
    {
        
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int num = 1, i;
            int count = 0;

            while (count < n)
            {
                num = num + 1;
                for ( i = 2; i <= num; i++)
                {
                    if (num % i == 0)
                    {
                        break;
                    }
                }
                if (i == num)
                {
                    count = count + 1;
                }
            }
            Console.WriteLine("Your nth prime is: " + num);
            Console.ReadKey();
        }
        
    }
}
