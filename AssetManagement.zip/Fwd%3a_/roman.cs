﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class roman
    {
        static string rom(string input1)
        {
            string res = "";
            for (int i = 0; i < input1.Length; i++)
            {
                res += getRoman((int)(input1[i])) + " ";
            }
            return res.Trim();
            //throw new NotImplementedException("Method  FindMessage(string input1) not Implemented.");
        }
        static string getRoman(int n)
        {
            string s = "";
            if (n <= 10)
            {
                switch (n)
                {
                    case 1:
                        s += "I";
                        break;
                    case 2:
                        s += "II";
                        break;
                    case 3:
                        s += "III";
                        break;
                    case 4:
                        s += "IV";
                        break;
                    case 5:
                        s += "V";
                        break;
                    case 6:
                        s += "VI";
                        break;
                    case 7:
                        s += "VII";
                        break;
                    case 8:
                        s += "VIII";
                        break;
                    case 9:
                        s += "IX";
                        break;
                    case 10:
                        s += "X";
                        break;
                }
            }
            else if (n > 10 && n < 40)
            {
                s += "X" + getRoman(n - 10);
            }
            else if (n == 40)
            {
                s += "XL";
            }
            else if (n > 40 && n < 50)
            {
                s += getRoman(40) + getRoman(n - 40);
            }
            else if (n == 50)
            {
                s += "L";
            }
            else if (n > 50 && n < 90)
            {
                s += getRoman(50) + getRoman(n - 50);
            }
            else if (n == 90)
            {
                s += "XC";
            }
            else if (n > 90 && n < 100)
            {
                s += getRoman(90) + getRoman(n - 90);
            }
            else if (n == 100)
            {
                s += "C";
            }
            else
            {
                s += getRoman(100) + getRoman(n - 100);
            }
            return s;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(rom("ABC"));
        }
    }
}
