﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{

    class sumDigit
    {
        //if inp = 789654 ; op = 3
        public static int func(int input1)
        {
            if (input1 >= -9 && input1 <= 9)
                return input1;
            int op = 0, res = 0, res1 = 0;
            int temp = Math.Abs(input1);

            while (temp > 0)
            {
                res += temp % 10;
                temp = temp / 10;
            }
            op = res;
            while(op > 9)
            {
                while(res > 0)
                {
                    res1 += res % 10;
                    res = res / 10;
                }
                
                res = res1;
                op = res1;
                res1 = 0;
            }
            if (input1 < -9)
                return -op;
            return op;
        }
        static void Main(string[] args)
        {
            int input1 = int.Parse(Console.ReadLine());
            Console.WriteLine(func(input1));
            Console.ReadKey();
        }
    }
}
