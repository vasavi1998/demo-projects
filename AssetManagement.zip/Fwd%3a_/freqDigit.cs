﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class freqDigit
    {
        //max repeated number; if more than one => greatest
        static int freq(int input1, int input2, int input3, int input4)
        {
            //List<int> a = new List<int>();
            int l = (input1.ToString().Length) + (input2.ToString().Length) + (input3.ToString().Length) + (input4.ToString().Length);
            int[] a = new int[l];
            int j = 0;
            while(input1 > 0)
            {
                a[j] = (input1 % 10);
                input1 /= 10;
                j++;
            }
            while (input2 > 0)
            {
                a[j] = (input2 % 10);
                input2 /= 10;
                j++;
            }
            while (input3 > 0)
            {
                a[j] = (input3 % 10);
                input3 /= 10;
                j++;
            }
            while (input4 > 0)
            {
                a[j] = (input4 % 10);
                input4 /= 10;
                j++;
            }
            int[] count = new int[10];
            for(int i = 0; i < a.Length; i ++)
            {
                count[a[i]]++;
            }
            
            int maxCount = count[0], res = 0;
            for(int i = 1; i < count.Length; i ++)
            {
                if(maxCount <= count[i])
                {
                    maxCount = count[i];
                   // res = i;
                }
            }
            for (int i = 0; i < count.Length; i++)
            {
                if (maxCount == count[i])
                {
                    if(res < i)
                        res = i;
                }
            }
            return res;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(freq(928, 369, 2335, 418));
            Console.ReadKey();
        }
    }
}
