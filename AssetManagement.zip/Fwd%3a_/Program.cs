﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            char[] c = str.ToCharArray();
            
            Array.Sort(c); 
            for(int i = 0; i < c.Length; i ++)
            {
                int ch = 1;
                for(int j = i+1 ; j<c.Length; j ++)

                {
                    if(c[i] == c[j])
                    {
                        ch++;
                        i = j;
                    }
                }
                Console.WriteLine("the letter {0} is repeated {1} times" ,c[i],ch);
            }

            Console.ReadKey();
        }
    }
}
