﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    class pin
    {
        static int res(int input1,int input2,int input3)
        {
            int p = 0, i = 0, temp = 0, l = 0;
            int a = input1, b = input2, c = input3;
            int[] num = new int[9];
            //int[] l = new int[3];
            while (a > 0)
            {
                num[i] = a % 10;
                a /= 10;
                i++;
            }
            while (b > 0)
            {
                num[i] = b % 10;
                b /= 10;
                i++;
            }
            while (c > 0)
            {
                num[i] = c % 10;
                c /= 10;
                i++;
            }
            l = Math.Min(num[2], num[5]);
            temp = (temp * 10) + Math.Min(l, num[8]);
            l = Math.Min(num[1], num[4]);
            temp = (temp * 10) + Math.Min(l, num[7]);
            l = Math.Min(num[0], num[3]);
            temp = (temp * 10) + Math.Min(l, num[6]);


            Array.Sort(num);
            p = ((num[8] * 1000) + temp);
            return p;
        }
        static void Main(string[] args)
        {
           
            Console.WriteLine(res(190,267,853));
        }
    }
}
