﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringDemo
{
    //input1 = no. of rows; input2 = initial value at 1st row; input3 = increment of initial value by input3
    class hillRange
    {
        static int hillRan(int input1,int input2,int input3)
        {
            int temp = input2, x = 0, hill = 0;
            for (int i = 1; i < input1; i++)
            {
                x = input2 + input3;
                for (int j = 0; j <= i; j++)
                {
                    hill += x;
                }
                input2 = x;
            }
            return (temp + hill);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(hillRan(5,10,2));
            Console.ReadKey();
        }
    }
}
