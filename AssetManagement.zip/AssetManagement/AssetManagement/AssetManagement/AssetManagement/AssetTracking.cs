﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        static SqlConnection objCon = new SqlConnection(ConnectionString);

        public bool AddAsset(Asset obj)
        {
            string s = string.Empty;
            Random rand = new Random();

            if (obj == null)
                return false;
            else
            {
                s = obj.AssetType.Substring(0, 2) + rand.Next(1, 1000).ToString();
                obj.SerialNo = s;
                string sn = "INSERT INTO ASSET VALUES('" + obj.AssetType + "','" + obj.SerialNo + "','" + obj.ProcurementDate + "','" + obj.TaggingStatus + "')";
                objCon.Open();
                SqlCommand add = new SqlCommand(sn, objCon);
                int i = add.ExecuteNonQuery();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public bool ModifyAsset(Asset obj)
        {
            
            if (obj == null)
                return false;
            else
            {
                string sn = "UPDATE ASSET SET ASSETTYPE='" + obj.AssetType + "',SERIALNO = '" + obj.SerialNo + "',PROCUREMENTDATE='" + obj.ProcurementDate + "',TAGGINGSTATUS='" + obj.TaggingStatus + "')";
                objCon.Open();
                SqlCommand update = new SqlCommand(sn, objCon);
                int i = update.ExecuteNonQuery();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public bool TagAsset(AssetTagging obj)
        {
            if (obj == null)
                return false;
            else
            {
                string q = "DECLARE @name varchar(20) set @name = (SELECT TAGGINGSTATUS FROM ASSET WHERE ASSETID = '" + obj.AssetID + "')IF @name = 'FREEPOOL' INSERT INTO ASSETTAGGING VALUES('" + obj.EmployeeID + "','" + obj.AssetID + "','" + obj.TaggingDate + "','" + obj.ReleaseDate + "') UPDATE ASSET SET TAGGINGSTATUS = 'TAGGED' WHERE ASSETID = '"+obj.AssetID+"'";
                if (objCon.State == System.Data.ConnectionState.Closed)
                    objCon.Open();
                SqlCommand sq = new SqlCommand(q, objCon);
                int i = sq.ExecuteNonQuery();
                if (i > 0)
                    return true;
                else
                    return false;
            }
        }

        public bool DeTagAsset(int intAssetId)
        {
            string cs1 = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
            SqlConnection objCon1 = new SqlConnection(cs1);
            string updtcmd = "UPDATE ASSETTAGGING SET RELEASEDATE='"+DateTime.Now+"' WHERE ASSETID = '"+intAssetId+"'";
            objCon1.Open();
            SqlCommand update = new SqlCommand(updtcmd,objCon1);
            int i = update.ExecuteNonQuery();

            string cs2= "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
            SqlConnection objCon2 = new SqlConnection(cs2);
            string delcmd = "UPDATE ASSET SET TAGGINGSTATUS = '"+"FREEPOOL"+"' WHERE ASSETID = '" + intAssetId + "'";
            objCon2.Open();
            SqlCommand del = new SqlCommand(delcmd, objCon2);
            int j = del.ExecuteNonQuery();

            if (i > 0 && j > 0)
                 return true;
            else return false;
        }
    }
}
