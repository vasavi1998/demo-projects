﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        public List<Employee>EmployeeList { get; set; }
        //TODO : Write your code here.
        public EmployeeData()
        {
            // TODO: Write your code here.
            EmployeeList= new List<Employee>();                                                                                                                                                                                                                                                                                                                      

        }
        public string AddEmployee(Employee obj)
        {
            if (obj == null)
            {
                return null;
            }
            else
            {
                Utility.EmployeeUtility objutility = new Utility.EmployeeUtility();
                objutility.GenerateUserName(obj, 1);
                EmployeeList.Add(obj);
                return obj.UserID;
            }
            //throw new NotImplementedException();
        }

        public bool ModifyEmployee(Employee obj)
        {
            bool isModified=false;
            if (obj == null)
            {
                isModified= false;
            }
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == obj.UserID)
                    {
                        EmployeeList[i] = obj;
                        isModified=true;
                    }
                }
               
            }
            // throw new NotImplementedException();
            return isModified;
        }

        public Employee SearchEmployee(string strUserID)
        {
            Employee Empobj = null;
            if (string.IsNullOrEmpty(strUserID))
            {
                Empobj = null;
            }
            else
            {
                for(int i = 0; i < EmployeeList.Count; i++)
                {
                    Empobj =  EmployeeList[i];
                }
            }
            return Empobj;
        }

        public bool DeleteEmployee(string strUserID)
        {
            bool b = false;
            if (string.IsNullOrEmpty(strUserID))
            {
                b = false;
            }
            else
            {
                for (int i= 0;i< EmployeeList.Count; i++){
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        EmployeeList.RemoveAt(i);
                        b = true;
                    }
                }
            }
            return b;
            //   throw new NotImplementedException();
        }
    }
}
