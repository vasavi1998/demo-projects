﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeData objemp = new EmployeeData();
            objemp.AddEmployee(new Employee("tanweer", "ahmed", 1997, 04, 23, "b.tech", 0.6));
        }
    }
}
