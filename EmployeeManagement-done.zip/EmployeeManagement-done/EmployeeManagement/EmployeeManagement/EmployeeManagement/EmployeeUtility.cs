﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
     
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            string strId = ((char)(obj.FirstName[0] + obj.FirstName.Length)).ToString()+ ((char)(obj.LastName[0] + obj.LastName.Length)).ToString();
            strId +=SumDigits(obj.BirthYear) + SumDigits(obj.BirthMonth) + SumDigits(obj.BirthDay) ;
            strId += EmployeeCount;
            obj.UserID = strId;
           // throw new NotImplementedException();
        }

        public string SumDigits(int value)
        {
            int sum = 0;
            string str;
            //throw new NotImplementedException();
            while (value != 0)
            {
                sum = sum + value % 10;
                value = value / 10;
            }
            str = Convert.ToString(sum);
            return str;
        }
    }
}
