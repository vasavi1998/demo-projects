﻿using System;

namespace VoterEntry
{
    public class Voter
    {
        // TODO: Write your code 
        public string VoterID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateofBirth{ get; set; }
        public int Age { get; set; }
        public string FathersName { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string ConstituencyName { get; set; }
        public Voter()
        {

        }
        public Voter(string FirstName,string LastName,DateTime DateOfBirth,int Age,string FatherName,string Gender,string Address,string ConstituencyName)
        {
            this.FirstName=FirstName;
            this.LastName = LastName;
            this.DateofBirth = DateOfBirth;
            this.Age = Age;
            this.FathersName = FatherName;
            this.Gender = Gender;
            this.Address = Address;
            this.ConstituencyName = ConstituencyName;
        }
    }
    
}
