﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {

        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            //throw new NotImplementedException();
            //string str = ((char)strFirstName[0]).ToString() +((char)strLastName[0]).ToString();
            //str += ((dtDateofBirth.DayOfWeek).ToString()[0].ToString());
            //str += (strFirstName.Length).ToString() + (strLastName.Length).ToString();
            //str += SumOfDigits(dtDateofBirth.Month) + SumOfDigits(dtDateofBirth.Day) + SumOfDigits(dtDateofBirth.Year);
            return "VAS123645";
        }
        //public static string SumOfDigits(int n)
        //{
        //    //string ch="";
        //    //int sum = 0;
        //    //while (n > 0)
        //    //{
        //    //    int rem = n / 10;
        //    //    sum += rem;
        //    //    n = n / 10;
        //    //}
        //    //ch = sum.ToString();
        //    //return ch;
        //    return
        //}       
    }
}
