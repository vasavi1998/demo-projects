﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeOperations
{
    public class EmployeeDAL
    {
        public List<Employee> ViewAllEmployees()
        {

            List<Employee> empList = new List<Employee>();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog =DemoDB; User Id= sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From Employee";
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    Employee emp = new Employee();

                    emp.EmpID = int.Parse(dr["EmpID"].ToString());
                    emp.EmpName = dr["EmpName"].ToString();
                    emp.Age = int.Parse(dr["Age"].ToString());
                    emp.Address = dr["Address"].ToString();
                    if (dr["Did"] != DBNull.Value)
                    {
                        emp.Did = int.Parse(dr["Did"].ToString());
                    }
                    else
                    {
                        emp.Did = 0;
                    }
                    empList.Add(emp);
                }
            }
            con.Close();
            return empList;
        }

        public int AddEmployee(Employee emp)
        {
            if (emp != null)
            {
               
                //string empid = utl.GenerateEmpID(emp);
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Server=.;Initial Catalog =DemoDB; User Id= sa;Password=wipro@123";
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into Employee(EmpName, Age, Address, Did) values (@en,@age,@add,@did); Select Scope_Identity()";
                cmd.Parameters.AddWithValue("@en", emp.EmpName);
                cmd.Parameters.AddWithValue("@age", emp.Age);
                cmd.Parameters.AddWithValue("@add", emp.Address);
                cmd.Parameters.AddWithValue("@did", emp.Did);
                cmd.Connection = con;
                con.Open();
                int empid = int.Parse(cmd.ExecuteScalar().ToString());
                con.Close();
                return empid;
            }
            else
            {
                return 0;
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            bool IsUpdated = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog =DemoDB; User Id= sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Update Employee Set EmpName = @en, Age = @age, Address = @add, Did = @did Where EmpID = @eid";
            cmd.Parameters.AddWithValue("@en", emp.EmpName);
            cmd.Parameters.AddWithValue("@age", emp.Age);
            cmd.Parameters.AddWithValue("@add", emp.Address);
            cmd.Parameters.AddWithValue("@did", emp.Did);
            cmd.Parameters.AddWithValue("@eid", emp.EmpID);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                IsUpdated = true;
            }
            return IsUpdated;
        }

        public bool DeleteEmployee(int empID)
        {
            bool IsDeleted = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog =DemoDB; User Id= sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Delete from Employee Where EmpID = @eid";
            cmd.Parameters.AddWithValue("@eid", empID);
            cmd.Connection = con;
            con.Open();
            int rowCount = cmd.ExecuteNonQuery();
            con.Close();
            if (rowCount == 1)
            {
                IsDeleted = true;
            }
            return IsDeleted;
        }

        public Employee SearchEmpByID(int empID)
        {
            Employee emp = new Employee();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=.;Initial Catalog =DemoDB; User Id= sa;Password=wipro@123";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * From Employee Where EmpID = @eid";
            cmd.Parameters.AddWithValue("@eid", empID);
            cmd.Connection = con;
            con.Open();

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                emp.EmpName = dr["EmpName"].ToString();
                emp.Age = int.Parse(dr["Age"].ToString());
                emp.Address = dr["Address"].ToString();
                emp.Did = int.Parse(dr["Did"].ToString());

            }
            con.Close();
            return emp;
        }
    }
}
