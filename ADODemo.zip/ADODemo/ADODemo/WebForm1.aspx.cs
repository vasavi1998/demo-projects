﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeOperations;

namespace ADODemo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        EmployeeDAL obj = new EmployeeDAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            List<Employee> eList = obj.ViewAllEmployees();
            GridView1.DataSource = eList;
            GridView1.DataBind();
            
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            Employee e1 = new Employee();
            e1.EmpName = TextBox2.Text;
            e1.Age = int.Parse(TextBox3.Text);
            e1.Address = TextBox4.Text;
            e1.Did = int.Parse(TextBox5.Text);
            int empid = obj.AddEmployee(e1);
            if(empid!= 0)
            {
                Response.Write("Record Inserted..!! EmpID is : "+empid);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Employee e1 = new Employee();
            e1.EmpID = int.Parse(TextBox1.Text);
            e1.EmpName = TextBox2.Text;
            e1.Age = int.Parse(TextBox3.Text);
            e1.Address = TextBox4.Text;
            e1.Did = int.Parse(TextBox5.Text);
            bool update = obj.UpdateEmployee(e1);
            if (update)
            {
                Response.Write("Record Updated..!!");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            bool deleted = obj.DeleteEmployee(int.Parse(TextBox1.Text));
            if (deleted)
            {
                Response.Write("Record Deleted..!!");
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Employee emp = obj.SearchEmpByID(int.Parse(TextBox1.Text));
            if(emp != null)
            {
                TextBox2.Text = emp.EmpName;
                TextBox3.Text = emp.Age.ToString();
                TextBox4.Text = emp.Address;
                TextBox5.Text = emp.Did.ToString();
            }
            else
            {
                Response.Write("No Records Found..!!");
            }
            
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}