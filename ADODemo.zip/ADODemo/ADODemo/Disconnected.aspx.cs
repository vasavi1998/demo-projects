﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace ADODemo
{
    public partial class Disconnected : System.Web.UI.Page
    {
        public DataTable GetAllEmployees()
        {
            SqlConnection con = new SqlConnection("Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123");
            SqlDataAdapter da = new SqlDataAdapter("Select * from Employee", con);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            DataSet ds = new DataSet();
            da.Fill(ds,"Employee");
            return ds.Tables["Employee"];

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dt = GetAllEmployees();
                ViewState["EmpData"] = dt;
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["EmpData"];
            DataRow dr = dt.NewRow();
            dr["EmpName"] = txtName.Text;
            dr["Age"] = txtAge.Text;
            dr["Address"] = txtAddress.Text;
            dr["Did"] = txtDid.Text;
            dt.Rows.Add(dr);
            ViewState["EmpData"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();


        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["EmpData"];
            DataRow dr = dt.Rows.Find(int.Parse(txtEmpID.Text));
            dr["EmpName"] = txtName.Text;
            dr["Age"] = txtAge.Text;
            dr["Address"] = txtAddress.Text;
            dr["Did"] = txtDid.Text;
            ViewState["EmpData"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["EmpData"];
            DataRow dr = dt.Rows.Find(int.Parse(txtEmpID.Text));
            dr.Delete();
            ViewState["EmpData"] = dt;
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["EmpData"];
            SqlConnection con = new SqlConnection("Server=.;Initial Catalog=DemoDB;User Id=sa;Password=wipro@123");
            SqlDataAdapter da = new SqlDataAdapter("Select * from Employee", con);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            SqlCommandBuilder cmdbldr = new SqlCommandBuilder(da);
            da.Update(dt);
        }
    }
}