﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking
{
    public class InternetBankingInfo : UserDetail
    {
        // TODO : Write your code Here.
        public string UserID { get; set; }
        public InternetBankingInfo(string firstname, string lastname, string dob, string gender, string maritalstatus, string fathername)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.DOB = Convert.ToDateTime(dob);
            this.Gender = gender;
            this.MaritalStatus = maritalstatus;
            this.FatherName = fathername;
        }
    }
}
