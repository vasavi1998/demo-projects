﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking.Utility
{
    public class BankingUtility
    {
        public string GenerateUserID(InternetBankingInfo obj)
        {
            string userId = "", outputUserid = "";
            string firstname = obj.FirstName.Trim();
            string lastname = obj.LastName.Trim();
            userId = firstname.Substring(0, 2).ToUpper() + lastname.Substring(2, 2).ToUpper() + (firstname.Length + lastname.Length).ToString();
            //string month = obj.DOB.Month.ToString();
            string month = obj.DOB.ToLongDateString();
            string[] monthstring = month.Split(' ');
            string monthChar = monthstring[1];
            //Console.WriteLine("month: " + month);
            int len = obj.FatherName.Length;
            userId += monthChar[0].ToString() + obj.FatherName[0].ToString().ToUpper() + obj.FatherName[len - 1].ToString().ToUpper();
            char[] output = userId.ToCharArray();
            Array.Reverse(output);
            for (int i = 0; i < output.Length; i++)
            {
                outputUserid += output[i].ToString();
            }
            return outputUserid;
           
        }

    }
}
