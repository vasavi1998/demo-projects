﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking
{
    class Program
    {
        static void Main(string[] args)
        {
            //InternetBankingInfo obj1 = new InternetBankingInfo("john","smith","06/21/1999","male","single","marx");
            //BankingData obj = new BankingData();
            //obj.AddBankingInfo(new InternetBankingInfo("john", "smith", "06/21/1999", "male", "single", "marx"));

            //Console.ReadKey();
        }
    }
}

