﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking
{
    public class UserDetail
    {
        //TODO: Write your Code Here.
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string MaritalStatus { get; set; }
        public string Gender { get; set; }
        public string FatherName { get; set; }
    }

}

