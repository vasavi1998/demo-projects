﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking
{
    public class BankingData
    {
        public List<InternetBankingInfo> BankingUserList { get; set; }
        public BankingData()
        {
            BankingUserList = new List<InternetBankingInfo>();
        }

        public string AddBankingInfo(InternetBankingInfo obj)
        {
            if (obj == null) return null;

            Utility.BankingUtility objBankingUtility = new Utility.BankingUtility();
            obj.UserID = objBankingUtility.GenerateUserID(obj);

            BankingUserList.Add(obj);
            return obj.UserID;
           
        }
        public InternetBankingInfo SearchBankingInfo(string strUserID)
        {
            InternetBankingInfo result = null;
            if (strUserID == null) return null;

            for (int i = 0; i < BankingUserList.Count; i++)
            {
                if (BankingUserList[i].UserID == strUserID)
                {
                    result = BankingUserList[i];
                    break;
                }
            }
            return result;
        }

    }
}