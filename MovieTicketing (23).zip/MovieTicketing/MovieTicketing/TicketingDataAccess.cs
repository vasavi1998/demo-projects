﻿using System;
using System.Data.SqlClient;

namespace MovieTicketing
{
    public class TicketingDataAccess
    {
        string ConnectionString = "Data Source=.;Initial Catalog=MovieTicketing;User ID=sa;Password=wipro@123";

        public bool AddMovie(Movies obj)
        {
            //throw new NotImplementedException();
            bool IsInserted = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Movies( MovieName,Director,PlaysPerDay,TicketPrice) values (@mn,@dn,@ppd,@tp)", con);
                cmd.Parameters.AddWithValue("@mn", obj.MovieName);
                cmd.Parameters.AddWithValue("@dn", obj.DirectorName);
                cmd.Parameters.AddWithValue("@ppd", obj.PlaysPerDay);
                cmd.Parameters.AddWithValue("@tp", obj.TicketPrice);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsInserted = true;
                }
            }
            return IsInserted;
        }

        public bool AddTheatre(Theatres obj)
        {
            //throw new NotImplementedException();
            bool IsInserted = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Theatres(TheatreName,SeatingCapacity) values (@tn,@sc)", con);

                cmd.Parameters.AddWithValue("@tn", obj.TheatreName);
                cmd.Parameters.AddWithValue("@sc", obj.SeatingCapacity);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsInserted = true;
                }
            }
            return IsInserted;
        }

        public bool AddShow(Shows obj)
        {
            //throw new NotImplementedException();
            bool IsInserted = false;
            if (obj != null)
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("Insert into Shows(ShowID,TheatreID,MovieID,StartDate,EndDate,StartTime,EndTime) values (@sid,@tid,@mid,@sd,@ed,@st,@et)", con);
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                cmd.Parameters.AddWithValue("@tid", obj.TheatreID);
                cmd.Parameters.AddWithValue("@mid", obj.MovieID);
                cmd.Parameters.AddWithValue("@sd", obj.StartDate);
                cmd.Parameters.AddWithValue("@ed", obj.EndDate);
                cmd.Parameters.AddWithValue("@st", obj.StartTime);
                cmd.Parameters.AddWithValue("@et", obj.EndTime);
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowcount == 1)
                {
                    IsInserted = true;
                }
            }
            return IsInserted;

        }


        public string AddTicket(Tickets obj)
        {
            //throw new NotImplementedException();
            string movieName = " ";
            decimal ticketPrice = 0;
            if (obj != null)
            {
                string query = "select m.MovieName,m.TicketPrice from Movies m JOIN Shows s ON m.MovieID=s.MovieID JOIN Tickets t ON s.ShowID=t.ShowID where t.ShowID=@sid ";
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@sid", obj.ShowID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    movieName = dr["MovieName"].ToString();
                    ticketPrice = decimal.Parse(dr["TicketPrice"].ToString());
                }
                else
                {
                    return null;
                }
                con.Close();
                obj.Amount = obj.NumberofPersons * ticketPrice;
                String refcode = obj.CustomerName[0].ToString() + obj.CustomerName[1].ToString() + obj.NumberofPersons.ToString() + movieName[0].ToString() + movieName[1].ToString() + obj.BookingDate.Day.ToString() + obj.BookingDate.Month.ToString();
                Random rd = new Random();
                int randomNumber = rd.Next(1, 1000);
                refcode = refcode + randomNumber.ToString();
                obj.ReferenceCode = refcode.ToUpper();
                SqlCommand cmd1 = new SqlCommand("Insert into Tickets(ShowID,ReferenceCode,CustomerName,Amount,NumberofPersons,BookingDate,TicketStatus)values(@sid,@ref,@cn,@amt,@nop,@bd,@ts)", con);
                cmd1.Parameters.AddWithValue("@sid", obj.ShowID);
                cmd1.Parameters.AddWithValue("@ref", obj.ReferenceCode);
                cmd1.Parameters.AddWithValue("@cn", obj.CustomerName);
                cmd1.Parameters.AddWithValue("@amt", obj.Amount);
                cmd1.Parameters.AddWithValue("@nop", obj.NumberofPersons);
                cmd1.Parameters.AddWithValue("@bd", obj.BookingDate);
                cmd1.Parameters.AddWithValue("@ts", obj.TicketStatus);
                con.Open();
                int rows = cmd1.ExecuteNonQuery();

                return obj.ReferenceCode;
            }
            else
            {
                return null;
            }


        }




        public int DeleteMovie(int intMovieID)
        {
            //throw new NotImplementedException();
            if (intMovieID != 0)
            {
                int rowsDeleted = 0;
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand("Select ShowID from Shows where MovieID=@mid", con);
                cmd1.Parameters.AddWithValue("@mid", intMovieID);
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        int ShowID = int.Parse(dr1["ShowID"].ToString());
                        SqlConnection con1 = new SqlConnection(ConnectionString);
                        SqlCommand cmd2 = new SqlCommand("Delete from Tickets where ShowID=@sid", con1);
                        cmd2.Parameters.AddWithValue("@sid", ShowID);
                        con1.Open();
                        int rows = cmd2.ExecuteNonQuery();
                        rowsDeleted += rows;
                        con1.Close();



                        if (rowsDeleted > 0)
                        {
                            SqlConnection con2 = new SqlConnection(ConnectionString);
                            SqlCommand cmd3 = new SqlCommand("Delete from Shows where ShowID=@sid", con2);
                            cmd3.Parameters.AddWithValue("@sid", intMovieID);
                            con2.Open();
                            int rowcount = cmd3.ExecuteNonQuery();
                            rowsDeleted += rowcount;
                            con2.Close();
                            if (rowcount > 0)
                            {
                                SqlConnection con3 = new SqlConnection(ConnectionString);
                                SqlCommand cmd4 = new SqlCommand("Delete from Movies where MovieID=@mid", con3);
                                cmd4.Parameters.AddWithValue("@mid", intMovieID);
                                con3.Open();
                                int delRows = cmd4.ExecuteNonQuery();
                                rowsDeleted += delRows;
                                con3.Close();
                                if (delRows == 1)
                                {
                                    return rowsDeleted;
                                }
                                else
                                {
                                    return rowsDeleted;
                                }
                            }
                            else
                            {
                                return rowsDeleted;
                            }
                        }
                        else
                        {
                            return rowsDeleted;
                        }
                    }
                }
                con.Close();
                return rowsDeleted;
            }
            else
                return 0;
        }
    }
}       
    

            
        



    




