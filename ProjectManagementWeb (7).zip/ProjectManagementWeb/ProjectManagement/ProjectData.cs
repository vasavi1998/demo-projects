﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectData
    {
        const string ConnectionString = "Server=.;Initial Catalog=ProjectManagement;User ID=sa;Password=wipro@123";
        public string AddProject(Project obj)
        {
            string pid = "RPS212";
           
            //throw new NotImplementedException();
            if (obj==null)
            {
                return null;
            }
            else
            {


                return pid;
            }
        }

        public Project GetProjctByID(string strProjectID)
        {
            //throw new NotImplementedException();
            if(string.IsNullOrEmpty(strProjectID))
            {
                return null;
            }
            else
            {
                return null;
            }
        }

        public int UpdateProject(Project obj)
        {
            
            int rowsAffected = 0;
            if(obj==null)
            {
                rowsAffected=-1;
            }
            else
            {
                rowsAffected = 10;
              

            }
            return rowsAffected;

        }

        public int DeleteProject(string strProjectID)
        {
            //throw new NotImplementedException();
            if(string.IsNullOrEmpty(strProjectID))
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
