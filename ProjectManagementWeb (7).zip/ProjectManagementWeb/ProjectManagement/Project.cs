﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class Project
    {
        // TODO: Write your code here.
        /* ProjectID as string
           ProjectName as string
           StartDate as DateTime
           Duration as int
           EndDate as DateTime*/
        public string ProjectID { get; set; }
        public string ProjectName { get; set; }
        public DateTime StartDate { get; set; }
        public int Duration { get; set; }
        public DateTime EndDate { get; set; }

    }
}
