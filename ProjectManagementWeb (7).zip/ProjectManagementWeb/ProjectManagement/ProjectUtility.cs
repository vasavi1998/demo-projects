﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectUtility
    {
        public string GenerateProjectID(string strProjectName)
        {
            string ProjectID = "";
            char[] chr = strProjectName.ToCharArray();
            if(chr[0]=='B')
            {
                ProjectID = "BUS";
            }
            else
            {
                ProjectID = "RPS";
            }

            
               
            
            return ProjectID;
        }
    }
}
