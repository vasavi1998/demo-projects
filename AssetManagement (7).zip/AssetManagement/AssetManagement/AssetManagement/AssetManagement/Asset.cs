﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class Asset
    {
        // TODO: Write your code here
        public int AssetID { get; set; }
        public String AssetType { get; set; }
        public String SerialNo { get; set; }
        public DateTime ProcurementDate { get; set; }
        public String TaggingStatus { get; set; }
    }
}
