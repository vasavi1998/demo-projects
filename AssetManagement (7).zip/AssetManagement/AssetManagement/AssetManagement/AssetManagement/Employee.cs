﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Employee
    {
        public String EmployeeID { get; set; }
        public String EmployeeName { get; set; }
        public DateTime DateOfJoining { get; set; }
        public String Email { get; set; }
        public String Location { get; set; }
        public long Phone { get; set; }
    }
}
