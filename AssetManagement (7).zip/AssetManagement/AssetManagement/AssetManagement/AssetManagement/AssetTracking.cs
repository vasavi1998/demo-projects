﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    public class AssetTracking
    {
        const string ConnectionString = "Data Source=.;Initial Catalog=AssetManagement;User ID=sa;Password=wipro@123";
        public bool AddAsset(Asset obj)
        {
            //throw new NotImplementedException();
            bool IsAdded= false;
            if (obj == null)
                return IsAdded;
            else
            {
                Random rd = new Random();
                int randomNo = rd.Next(1, 1000);
                obj.SerialNo= obj.AssetType[0].ToString() + obj.AssetType[1].ToString()+randomNo.ToString();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("insert into Asset(ASSETTYPE,SERIALNO,PROCUREMENTDATE,TAGGINGSTATUS) values(@at,@sn,@pd,@ts)", con);
                cmd.Parameters.AddWithValue("@at", obj.AssetType);
                cmd.Parameters.AddWithValue("@sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("@pd", DateTime.Now);
                cmd.Parameters.AddWithValue("@ts", "FREE POOL");
                con.Open();
                int rowcount = cmd.ExecuteNonQuery();
                con.Close();

                if (rowcount == 1)
                {
                    IsAdded= true;
                }
                else
                {
                    return IsAdded;
                }

            }
            return IsAdded;
        }

        public bool ModifyAsset(Asset obj)
        {
            //throw new NotImplementedException();
            bool IsUpdated = false;
            if (obj == null)
                return IsUpdated;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("update Asset set ASSETTYPE=@at,SERIALNO=@sn,PROCUREMENYDATE=@pd,TAGGINGSTATUS=@ts", con);
                cmd.Parameters.AddWithValue("at", obj.AssetType);
                cmd.Parameters.AddWithValue("sn", obj.SerialNo);
                cmd.Parameters.AddWithValue("pd", obj.ProcurementDate);
                cmd.Parameters.AddWithValue("ts", obj.TaggingStatus);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount == 1)
                {
                    IsUpdated = true;
                }
                else
                {
                    return IsUpdated;
                }
                return IsUpdated;
            }
        }

        public bool TagAsset(AssetTagging obj)
        {
            //throw new NotImplementedException();
            bool IsTagged = false;
            string taggingStatus = "";
            if (obj == null)
                return IsTagged;
            else
            {
                string query = "select TAGGINGSTATUS from Asset where ASSETID=@aid";
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand(query,con);
                cmd.Parameters.AddWithValue("@aid", obj.AssetID);
                con.Open();
                SqlDataReader drr = cmd.ExecuteReader();
                if (drr.HasRows)
                {
                    while (drr.Read())
                    {
                        taggingStatus = drr["TAGGINGSTATUS"].ToString().ToUpper();
                        if (taggingStatus == "FREE POOL")
                        {
                            SqlConnection con1 = new SqlConnection(ConnectionString);
                            SqlCommand Cmd1 = new SqlCommand("insert into AssetTagging (EMPLOYEEID,ASSETID,TAGGINGDATE,RELEASEDATE)values (@eid,@sid,@td,NULL)", con1);
                            Cmd1.Parameters.AddWithValue("@eid", obj.EmployeeID);
                            Cmd1.Parameters.AddWithValue("@sid", obj.AssetID);
                            Cmd1.Parameters.AddWithValue("@td", obj.TaggingDate);
                            con1.Open();
                            int rc = Cmd1.ExecuteNonQuery();
                            con1.Close();
                            if (rc > 0)
                            {
                                SqlConnection con2 = new SqlConnection(ConnectionString);
                                SqlCommand cmd2 = new SqlCommand("update Asset set TAGGINGSTATUS=@ts where ASSETID=@aid", con2);
                                cmd2.Parameters.AddWithValue("@ts", "tagged");
                                cmd2.Parameters.AddWithValue("@aid", obj.AssetID);
                                con2.Open();
                                int r = cmd2.ExecuteNonQuery();
                                con2.Close();
                                if (r > 0)
                                {
                                    IsTagged = true;
                                }
                            }

                        }
                    }
                }
                con.Close();
                return IsTagged;
            }
                
        }

        public bool DeTagAsset(int intAssetId)
        {
            //throw new NotImplementedException();
            if (intAssetId == 0)
                return false;
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("update Asset set TAGGINGSTATUS='free pool' where ASSETID=@aid", con);
                cmd.Parameters.AddWithValue("@aid", intAssetId);
                SqlConnection con1 = new SqlConnection(ConnectionString);
                SqlCommand cmd1 = new SqlCommand("update AssetTagging set RELEASINGDATE=@rd where ASSERTID=@aid");
                cmd1.Parameters.AddWithValue("@aid", intAssetId);
                cmd1.Parameters.AddWithValue("@rd", DateTime.Now);
                return true;
            }
                
        }
    }
}
