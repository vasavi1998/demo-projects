﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
   public  class InvalidUnitsException: Exception
    {
        public InvalidUnitsException(string strMessage):base(strMessage)
    }
}
