﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling
{
   public class BillingData
    {
      public List<Bill> Bills { get; set; }
    }
    public  BillingData()
    {
        Bills = new List<Bill>();
    }
    public bool GenerateBill(Bill obj)
    {
        bool isAdded = false;
        if (obj == null)
        {
            return false;
        }
        else
        {
            Random ran = new Rqandom();
            obj.BillingID = ran.Next();
            Utility.BillingUtility biluti = new Utility.BillingUtility();
            obj.TotalAmount = biluti.CalculateBill(obj.Units, obj.OutstandingAmount);
            Bills.Add(obj);
            isAdded = true;
        }
        return isAdded;
    }
    public Bill SearchBill(int intBillingID)
    {
        Bill bill = new Bill();
        bill = null;
        if (intBillingID <= 0)
        {
            return null;
        }
        else
        {
            for(int i=0;i<Bills.Count;i++)
            {
                if (Bills[i].BillingID == intBillingID)
                {
                    bill = Bills[i];
                }
            }
        }
        return bill;
    }
    public bool UpdateBill(Bill obj)
    {
        bool isUpdated = false;
        if (obj == null)
        {
            return false;
        }
        else
        {
            for (int i = 0; i < Bills.Count; i++)
            {
                if (Bills[i].BillingID == obj.BillingID)
                {
                    Utility.BillingUtility bilUti = new Utility.BillingUtility();
                    obj.TotalAmount = bilUti.CalculateBill(obj.Units, obj.OutstandingAmount);
                    obj.BillingDate = DateTime.Now;
                    Bills[i] = obj;
                    isUpdated = true;
                }
            }
        }
        return isUpdated;
    }
        