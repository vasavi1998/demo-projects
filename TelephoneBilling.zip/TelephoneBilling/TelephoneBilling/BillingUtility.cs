﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelephoneBilling.Utility
{
    public class BillingUtility
    {
        public decimal CalculateBill(int intNumberOfUnits, decimal decOutstandingAmount = 0.0m)
        {
            decimal chargeUnit = 0;
            decimal total = 0;
            try
            {
                if (intNumberOfUnits < 0)
                {
                    throw new TelephoneBilling.Exceptions.InvalidUnitsException("Invalid units.Billsble units should");
                }
                else
                {
                    if (intNumberOfUnits <= 250)
                    {
                        chargeUnit = 1.50m;
                    }
                    else if (intNumberOfUnits >= 251 && intNumberOfUnits <= 500)
                    {
                        chargeUnit = 2.50m;
                    }
                    else if (intNumberOfUnits > 500)
                    {
                        chargeUnit = 4.00m;
                    }
                    total = (intNumberOfUnits * chargeUnit) + 200 + decOutstandingAmount;
                }
            }
            catch (TelephoneBilling.Exceptions.InvalidUnitsException e)
            {
                Console.WriteLine(e.Message);
                throw e;
            }
            return total;
        }
    }
}
    