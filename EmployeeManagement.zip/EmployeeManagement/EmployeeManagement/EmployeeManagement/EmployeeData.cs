﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        //TODO : Write your code here.
        public EmployeeData()
        {
            // TODO: Write your code here.
        }
        public string AddEmployee(Employee obj)
        {
            throw new NotImplementedException();
        }

        public bool ModifyEmployee(Employee obj)
        {
            throw new NotImplementedException();
        }

        public Employee SearchEmployee(string strUserID)
        {
            throw new NotImplementedException();
        }

        public bool DeleteEmployee(string strUserID)
        {
            throw new NotImplementedException();
        }
    }
}
