﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            throw new NotImplementedException();
        }

        public string SumDigits(int value)
        {
            throw new NotImplementedException();
        }
    }
}
